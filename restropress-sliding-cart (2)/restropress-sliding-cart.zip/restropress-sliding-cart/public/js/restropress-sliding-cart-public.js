(function( $ ) {
    'use strict';
    setInterval(function () {
        var data = {
            'action': 'get_cart_details',
        };

        $.ajax({
            url: ajax_object.ajax_url,
            type: 'post',
            data: data,
            success: function (response) {
                var subtotal = response.subtotal;
                var cartDetails = response.cart_details;
                var enable = response.set_enable;
                // Update subtotal and cartDetails
                $('#rpress-floating-cart-icon span sup').text(cartDetails); 
                if (enable === 1 && sidebarVisible) {
                    // If sidebar is visible, hide it
                    $("#sliding-cart-window").hide();
                    sidebarVisible = false;
                } else if (enable === 1 && !sidebarVisible) {
                    // If sidebar is not visible, show it
                    $("#sliding-cart-window").show();
                    sidebarVisible = true;
                }
            },
            error: function (error) {
                console.error('AJAX Error:', error);
            }
        });
    }, 1000);
    jQuery(document).ready(function($) {
        // Toggle the visibility of .rpress-sidebar-cart when the icon is clicked
        $("#rpress-floating-cart-icon").on("click", function() {
          $('.rp-cart-left-wrap').trigger('click');
          adjustFoodItemsListWidth();  // Adjust the width when the icon is clicked
        });
        // Add an event handler to the close icon using jQuery
        $(".fa.fa-times.close-cart-ic").on("click", function() {
            adjustFoodItemsListWidth();  // Adjust the width when the close icon is clicked
        });
        function adjustFoodItemsListWidth() {
            const $foodItemsList = $('.rpress_fooditems_list');
            $foodItemsList.removeClass('rp-col-lg-8').addClass('full-width');
        }
    });    
})( jQuery );






